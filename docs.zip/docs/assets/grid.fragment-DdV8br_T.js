import{n as e}from"./rolldown-runtime-B0Z9INg1.js";import{n as t,t as n}from"./shaderStore-DBiNfWDC.js";import{r,t as i}from"./clipPlaneFragment-Birz0QQu.js";import{r as a,t as o}from"./clipPlaneFragmentDeclaration-BeW0wzU5.js";import{r as s,t as c}from"./fogFragmentDeclaration-Bnhxysih.js";import{n as l,t as u}from"./logDepthFragment-DrurZwyM.js";import{n as d,t as f}from"./fogFragment-B7tBOW4n.js";import{n as p,t as m}from"./logDepthDeclaration-CXHAYacR.js";import{n as h,t as g}from"./imageProcessingCompatibility-CBHq_lTp.js";var _,v,y,b;e((()=>{t(),a(),m(),s(),r(),d(),u(),h(),_=`gridPixelShader`,v=`#extension GL_OES_standard_derivatives : enable
#define SQRT2 1.41421356
#define PI 3.14159
#define MAX_OCTAVES 8
#define LINE_WIDTH_SCREEN_FRACTION 0.004
#define HORIZON_FADE_EXPONENT 400.0
#define ORIGIN_MARKER_SPAN 10000000.0
#define ORIGIN_MARKER_WIDTH_SCALE 0.00000015
#define ORIGIN_MARKER_THRESHOLD 0.0001
#define TRANSPARENT_MIN_OPACITY 0.08
precision highp float;uniform float visibility;uniform vec3 mainColor;uniform vec3 lineColor;uniform vec4 gridControl;uniform vec3 gridOffset;uniform float gridThicknessModifier;
#ifdef MULTI_SCALE
uniform float minGridSpacing;uniform float gridOctaves;
#endif
#if defined(HORIZON_FADE) || defined(BELOW_LINE_COLOR) || defined(ORIGIN_MARKER)
uniform vec3 cameraPosition;uniform vec2 viewportSize;
#endif
#ifdef BELOW_LINE_COLOR
uniform vec3 belowLineColor;
#endif
varying vec3 vPosition;varying vec3 vNormal;
#if defined(HORIZON_FADE) || defined(BELOW_LINE_COLOR) || defined(ORIGIN_MARKER)
varying vec3 vWorldPos;
#endif
#ifdef LOGARITHMICDEPTH
#extension GL_EXT_frag_depth : enable
#endif
#include<clipPlaneFragmentDeclaration>
#include<logDepthDeclaration>
#include<fogFragmentDeclaration>
#ifdef OPACITY
varying vec2 vOpacityUV;uniform sampler2D opacitySampler;uniform vec2 vOpacityInfos;
#endif
float getDynamicVisibility(float position) {float majorGridFrequency=gridControl.y;if (floor(position+0.5)==floor(position/majorGridFrequency+0.5)*majorGridFrequency)
{return 1.0;}
return gridControl.z;}
float getAnisotropicAttenuation(float differentialLength) {const float maxNumberOfLines=10.0;return clamp(1.0/(differentialLength+1.0)-1.0/maxNumberOfLines,0.0,1.0);}
float isPointOnLine(float position,float differentialLength) {float fractionPartOfPosition=position-floor(position+0.5); 
fractionPartOfPosition/=differentialLength; 
#ifdef ANTIALIAS
fractionPartOfPosition=clamp(fractionPartOfPosition,-1.,1.);float result=0.5+0.5*cos(fractionPartOfPosition*PI); 
return result;
#else
return abs(fractionPartOfPosition)<SQRT2/4. ? 1. : 0.;
#endif
}
float contributionOnAxis(float position,float tcLineWidthCap,float thicknessModifier) {float dPosDx=dFdx(position);float dPosDy=dFdy(position);float differentialLength=length(vec2(dPosDx,dPosDy))*SQRT2;if (tcLineWidthCap>0.0) {differentialLength=max(differentialLength,tcLineWidthCap);}
float lineWidth=differentialLength*thicknessModifier;float result=isPointOnLine(position,lineWidth);result*=getDynamicVisibility(position);result*=getAnisotropicAttenuation(differentialLength);return result;}
float normalImpactOnAxis(float x) {float normalImpact=clamp(1.0-3.0*abs(x*x*x),0.0,1.0);return normalImpact;}
#define CUSTOM_FRAGMENT_DEFINITIONS
void main(void) {
#define CUSTOM_FRAGMENT_MAIN_BEGIN
#include<clipPlaneFragment>
vec3 normal=normalize(vNormal);float horizonFade=1.0;float tcLineWidthCap=0.0;
#if defined(HORIZON_FADE) || defined(ORIGIN_MARKER)
float tc=length(vWorldPos-cameraPosition);
#endif
#ifdef HORIZON_FADE
tcLineWidthCap=LINE_WIDTH_SCREEN_FRACTION*tc/viewportSize.y;vec3 rd=normalize(vWorldPos-cameraPosition);if (abs(rd.y)>0.99) {horizonFade=1.0;} else {vec3 flatRayDir=normalize(vec3(rd.x,0.0,rd.z));horizonFade=-pow(abs(dot(rd,flatRayDir)),HORIZON_FADE_EXPONENT)+1.0;}
#endif
float grid=0.0;
#ifdef MULTI_SCALE
for (int i=0; i<MAX_OCTAVES; i++) {if (i>=int(gridOctaves)) break;float scale=minGridSpacing*pow(10.0,float(i));vec3 gridPos=(vPosition+gridOffset.xyz)/scale;float gx=contributionOnAxis(gridPos.x,tcLineWidthCap,gridThicknessModifier)*normalImpactOnAxis(normal.x);float gy=contributionOnAxis(gridPos.y,tcLineWidthCap,gridThicknessModifier)*normalImpactOnAxis(normal.y);float gz=contributionOnAxis(gridPos.z,tcLineWidthCap,gridThicknessModifier)*normalImpactOnAxis(normal.z);
#ifdef MAX_LINE
grid=max(grid,clamp(max(max(gx,gy),gz),0.,1.));
#else
grid=max(grid,clamp(gx+gy+gz,0.,1.));
#endif
}
#else
float gridRatio=gridControl.x;vec3 gridPos=(vPosition+gridOffset.xyz)/gridRatio;float x=contributionOnAxis(gridPos.x,tcLineWidthCap,gridThicknessModifier)*normalImpactOnAxis(normal.x);float y=contributionOnAxis(gridPos.y,tcLineWidthCap,gridThicknessModifier)*normalImpactOnAxis(normal.y);float z=contributionOnAxis(gridPos.z,tcLineWidthCap,gridThicknessModifier)*normalImpactOnAxis(normal.z);
#ifdef MAX_LINE
grid=clamp(max(max(x,y),z),0.,1.);
#else
grid=clamp(x+y+z,0.,1.);
#endif
#endif
grid*=horizonFade;
#ifdef ORIGIN_MARKER
float tcOrigin=ORIGIN_MARKER_WIDTH_SCALE*tc/viewportSize.y;float ox=contributionOnAxis(vWorldPos.x/ORIGIN_MARKER_SPAN,tcOrigin,gridThicknessModifier);float oz=contributionOnAxis(vWorldPos.z/ORIGIN_MARKER_SPAN,tcOrigin,gridThicknessModifier);float originMask=clamp(ox+oz,0.0,1.0)*horizonFade;if (originMask>ORIGIN_MARKER_THRESHOLD) grid=originMask;
#endif
#ifdef BELOW_LINE_COLOR
bool belowSurface=cameraPosition.y<vWorldPos.y;vec3 effectiveLineColor=belowSurface ? belowLineColor : lineColor;
#else
vec3 effectiveLineColor=lineColor;
#endif
vec3 color=mix(mainColor,effectiveLineColor,grid);
#ifdef FOG
#include<fogFragment>
#endif
float opacity=gridControl.w;
#ifdef LINES_ONLY
if (grid<0.01) discard;opacity=clamp(grid,TRANSPARENT_MIN_OPACITY,gridControl.w*grid);
#endif
#ifdef OPACITY
opacity*=texture2D(opacitySampler,vOpacityUV).a;
#endif
gl_FragColor=vec4(color.rgb,opacity*visibility);
#ifdef PREMULTIPLYALPHA
gl_FragColor.rgb*=opacity;
#endif
#include<logDepthFragment>
#include<imageProcessingCompatibility>
#define CUSTOM_FRAGMENT_MAIN_END
}
`,n.ShadersStore[_]||(n.ShadersStore[_]=v),y=[o,p,c,i,f,l,g];for(let e of y)n.IncludesShadersStore[e.name]||(n.IncludesShadersStore[e.name]=e.shader);b={name:_,shader:v}}))();export{b as gridPixelShader};